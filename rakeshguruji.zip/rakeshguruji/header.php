<!doctype html>
<html class="no-js" lang="en">

<head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>Kalsarp Dosh Nivaran Puja at Trimbakeshwar - Hire a Kalsarp Yog Puja Pandit</title>
      <meta name="robots" content="noindex, follow">
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Favicon -->
      <link rel="shortcut icon" type="image/x-icon" href="images/guruji/favi.png">
      <!-- CSS
         ============================================ -->
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- Fontawesome -->
      <link rel="stylesheet" href="css/fontawesome.css">
      <!-- Flaticon -->
      <link rel="stylesheet" href="css/flaticon.css">
      <!-- Base Icons -->
      <link rel="stylesheet" href="css/pbminfotech-base-icons.css"> 
	  <!-- AOS -->
	  <link rel="stylesheet" href="css/aos.css">
      <!-- Swiper -->
      <link rel="stylesheet" href="css/swiper.min.css">
      <!-- Magnific -->
      <link rel="stylesheet" href="css/magnific-popup.css"> 
      <!-- Shortcode CSS -->
      <link rel="stylesheet" href="css/shortcode.css">
	  <!-- Themify Icons -->
	  <link rel="stylesheet" href="css/themify-icons.css">
      <!-- Demo Base CSS -->
      <link rel="stylesheet" href="css/demo-2.css">
      <!-- Base CSS -->
      <link rel="stylesheet" href="css/base.css">
      <!-- Style CSS -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- REVOLUTION STYLE SHEETS -->
      <link rel="stylesheet" type="text/css" href="revolution/rs6.css">
         <link rel="stylesheet"  href="css/main.css">
    
   </head>
   <body >
      <!-- page wrapper -->
      <div class="page-wrapper">

        <!-- Header Main Area -->
		<header class="site-header header-style-5" style="background-image:url(images/guruji/texture.jpg); background-size:cover;">
			<div class="site-header-menu">
				<div class="container">
					<div class="row g-0">
						<div class="col-md-12">
							<div class="d-flex align-items-center justify-content-between navwrph">
								<div class="pbmit-header-wrapper">
									<div class="site-branding">
										<span class="site-title">
											<a href="index.php">
												<img class="logo-img" src="images/guruji/newlogo.png" alt="">
												<img class="sticky-logo" src="images/guruji/newlogo.png" alt="">
											</a>
										</span>
									</div>
									<div class="site-navigations">
										<nav class="main-menu navbar-expand-xl navbar-light">
											<div class="navbar-header">
												<!-- Toggle Button --> 
												<button class="navbar-toggler" type="button">
													<i class="pbmit-moversco-icon-bars"></i>
												</button>
											</div>
											<div class="pbmit-mobile-menu-bg"></div>
											<div class="collapse navbar-collapse clearfix show" id="pbmit-menu">
												<div class="pbmit-menu-wrap">
													<ul class="navigation clearfix">
														<li class="active">
															<a href="index.php">Home</a>
														
														</li>
														<li class="">
															<a href="about.php">About</a>
														
														</li>
														<li class="">
															<a href="kalsarp-yog-puja.php"> kalsarp Yog Puja</a>
															
														</li> 
														<li class="dropdown">
															<a href="">Our Puja's</a>
															<ul>
																<li><a href="kalsarp-yog-puja.php">kalsarp Yog Puja</a></li>
																<li><a href="mahamrityunjay.php"> Mahamrityunjay  pooja </a></li>
																<li><a href="pitru-dosh.php">Pitru dosh </a></li>
																<li><a href="rudra-abhishek.php">Rudrabhisek</a></li>
																<li><a href="navgrah-shanti.php">Navgrah shaanti </a></li>
															</ul>
														</li>
														<li class="n">
															<a href="gallery.php">Gallery</a>
															
														</li>
														<li><a href="contact.php">Contacts</a></li>
													</ul>
												</div>
											</div>
										</nav>
									</div>
								</div>
								<div class="pbmit-right-side">
									<!--<ul class="pbmit-social-links">-->
									<!--	<li class="pbmit-social-li pbmit-social-facebook">-->
									<!--		<a href="#" target="_blank">-->
									<!--			<span><i class="pbmit-base-icon-facebook"></i></span>-->
									<!--		</a>-->
									<!--	</li>-->
									<!--	<li class="pbmit-social-li pbmit-social-twitter">-->
									<!--		<a href="#" target="_blank">-->
									<!--			<span><i class="pbmit-base-icon-twitter"></i></span>-->
									<!--		</a>-->
									<!--	</li>-->
									<!--	<li class="pbmit-social-instagram">-->
									<!--		<a class=" tooltip-top" target="_blank" href="#">-->
									<!--			<i class="pbmit-base-icon-instagram"></i>-->
									<!--		</a>-->
									<!--	</li>-->
									<!--</ul>-->
									<div class="">
									 <a href="tel:+91 9890702222" class="pbmit-btn pbmit-btn-lg">+91 9890702222</a>
									</div> 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- Header Main Area End Here -->