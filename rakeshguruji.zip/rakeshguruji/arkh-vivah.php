<?php include'header.php';?>
 <!-- Title Bar -->
         <div class="pbmit-title-bar-wrapper " style="background-image:url(images/guruji/ser-img/bgser.jpg);">
            <div class="auto-container paddcon">
              <div class="row">
                  <div class="col-md-7 col-lg-7">
                       <div class="pbmit-title-bar-content">
                  <div class="pbmit-title-bar-content-inner">
                     <div class="pbmit-tbar">
                        <div class="pbmit-tbar-inner container">
                           <h1 class="pbmit-tbar-title">ARKH VIVAH DOSH NIVARAN POOJA TRIMBAKESHWAR</h1>
                        </div>
                     </div>
                     <div class="pbmit-breadcrumb">
                        <div class="pbmit-breadcrumb-inner">
                           <span><a title="" href="index.php" class="home"><span>Home</span></a></span>
                           <span class="sep">-</span>
                           <span><span class="post-root post post-post current-item">Arkh Vivah Pooja</span></span>
                        </div>
                     </div>
                  </div>
               </div>
                  </div>
                             <div class="col-md-5 col-lg-5">
                   <div class="form-wrp">
                       <form method="post" id="contact-form">
									<div class="row"> 
									<div class="col-md-12">
									   <h2 class="pbmit-titlee">MAKE AN ENQUIRY</h2>
									</div>
										<div class="col-md-12">
											<input type="text" name="name" class="form-control" placeholder="Your Name" required="">
										</div>
										<div class="col-md-12">
											<input type="text" name="transport-type" class="form-control" placeholder="Phone" required="">
										</div>
										<div class="col-md-12">
											<input type="date" name="subject" class="form-control" placeholder="Email" required="">
										</div>
										<div class="col-md-12">
											<button type="submit" class="pbmit-btn w-100">
												<i class="form-btn-loader fa fa-circle-o-notch fa-spin fa-fw margin-bottom d-none"></i>
												Book Your Puja
											</button>
										</div>
										
									</div>
								</form>
                   </div>
               </div>
              </div>
            </div>
         </div>
         <!-- Title Bar End-->
         
         
          <section class="mainsection">
				<div class="container">
					<div class="row align-items-center">
						<!--<div class="col-lg-4 service-left-col order-2 order-lg-1">-->
						<!--	<aside class="service-sidebar">-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="all-post-list">-->
						<!--				<ul>-->
						<!--					<li><a href="services-details.html">  Kalsarp Yog Puja </a></li>-->
						<!--					<li class="post-active"><a href="services-details.html"> Rudrabhisek </a></li>-->
						<!--					<li><a href="services-details.html">  Mahamrityunjay  pooja  </a></li>-->
						<!--					<li><a href="services-details.html"> Pitru dosh  </a></li>-->
						<!--					<li><a href="services-details.html"> Navgrah shaanti  </a></li>-->
						<!--				</ul>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="textwidget">-->
						<!--				<div class="single-service-contact">-->
						<!--					<div class="single-service-contact-inner">-->
						<!--						<span><i class="pbmit-moversco-business-icon-headset"></i></span>-->
						<!--						<h3>For More Details<br> Call Us</h3>-->
						<!--						<ul class="ctc">-->
						<!--							<li>-->
						<!--								<i class="pbmit-base-icon-phone"></i> <a href="tel:+91 9890702222">-->
						<!--								    +91 9890702222-->
						<!--								</a> -->
						<!--							</li>-->
												
						<!--						</ul>-->
						<!--					</div>-->
						<!--				</div>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--	</aside>-->
						<!--</div>-->
						<div class="col-lg-6 col-md-6  order-1">
							<img src="images/guruji/ser-img/Navgraha.jpg" class="w-100" alt="">
						
						</div>
						<div class="col-md-6 col-lg-6"> 
						    	<div class="service-details">
								<h3 class="pbmit-title">Arkh Vivah (Male) Dosh Nivaran Pooja</h3>
								<p>When the combination in the horoscope are not favorable for marriage and indicate problems to health or longevity of the couple, then Arkh Vivah (Male) Dosh Nivaran Pooja is suggested. During this the bride is first married to an Arkh Tree and then with the groom to take away bad effects due to doshas in the horoscope.</p>
								<p>This puja is done to get a happy marriage life if someone is affected by mangal dosh.</p>
								<p>Kumbh vivah is a combination of two words kumbh which means a pot and vivah means marriage.</p>
								<p>Manglik dosh is a kind of error in horoscope which affects after the wedding only and show its true effects after the marriage.</p>
							
							
							</div>
						</div>
					</div>
				</div>
            </section>
            
            
            <section  class="py-5" style="background-image: url(images/guruji/ser-img/ctcbgg.jpg);
                                        height: 300px;
                                        width: 100%;
                                        background-size: cover;
                                        background-position: center;">
                                    <div class="container">
                                        <div class="row justify-content-end">
                                            <div class="col-md-6">
                                                <div>
                                                    <h2>Book Your Puja with Ease</h2>
                                                    <p>Experience divine blessings with a hassle-free booking for your sacred rituals.</p>
                                                    <a href="contact.php" class="pbmit-btnn pbmit-btn-lg">Book Your Puja</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
            
            <section> 
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="service-page-infobox">
									<div class="row align-items-center">
										<div class="col-md-6">
											<img src="images/guruji/ser-img/effect.jpg" class="img-fluid" alt="">
										</div>
										<div class="col-md-6">
											<div class="service-list-group">
												<h3 class="pbmit-title" >Arkh Vivah Pooja At Trimbakeshwar</h3>
											
												<p>This puja is done at mangalnath temple in Trimbakeshwar.</p>
												
												<p>The highest degree of this Manglik dosh is formed when mars is placed in ascendant or the seventh house. These two placements form two most severe manglik dosh out of which placement in seventh is the most severe of all. Next in severity in decreasing order come the mars in eighth house, then forth and then twelfth house. In addition to mars, Sun, Saturn, Rahu and ketu’s placement in the houses mentioned above also forms partial Manglik dosh. So it is prefer to do Arkh vivah pooja at trimbakeshwar.</p>
												
												<p>Why Mars causes this Dosh ? Mars is considered the most malific planet as far as marriage of a person is considered. Mars is a fierce planet and its placement in certain houses results in Mangalik dosha. Marriage is considered as one of the most auspicious ceremony. In hindi the word Manglik denotes auspiciousness. Hence a manglik dosha makes the even inauspicious or causes problems in this event.</p>
												
											<p>What are the effects of Manglik Dosha ? The most common effect of Manglik dosha is - Delay in Marriage. </p>

                                        <p>Manglik dosha causes the marriage to be solemnized as late as at the age of 34 years, 38 years and even in 40s.</p>

                                        <p>Apart from this if a manglik boy/girl is married to a non-manglik spouse then the event of death or severe accidents have been witnessed by many couples which lead to death, permanent disability of the non-manglik spouse.</p>
											
											</div>
										</div>
									</div>
								</div>
								
								 
								
								
                            
                                <div class="con-ser">
                                <h3 class="pbmit-title">Positive Effects Of Navagraha Pooja Vidhi:</h3> 
                                <ul class="serul">
                                    <li>Helps remove negative effects of particular Grahas.</li>
                                     <li>Improves quality of personal and professional life.</li>
                                      <li>Gains the positive blessings of the Navagrahas.</li>
                                       <li>Keeps away bad luck and misfortune.</li>
                                        <li>Keeps away diseases and ailments.</li>
                                         <li> Helps to attain salvation (Moksha).</li>

                                    

                                </ul>
                            </div>
                             <div class="service-page-infobox">
									<div class="row align-items-center">
									
										<div class="col-md-6">
											<div class="service-list-group">
												<h3 class="pbmit-title" >About Trimbakeshwar in Nashik</h3>
												<p class="text-justify">Shri Trimbakeshwar Temple is located at a distance of about 30-km from Nasik in Maharashtra near the mountain named Brahmagiri from which the river Godavari flows. Trimbakeshwar Temple is revered as one of the 12 Jyotirlinga shrines of Shiva and as the source of the river Godavari. Just as Ganga is known as Bhagirathi and is one of the most important rivers in North India, in the same way, Godavari is also known as Gautami Ganga and is the most sacred river in South India. According to Shiv Purana, it is because of the earnest request of Godavari, Gautam Rishi and other gods that Lord Shiva agreed to reside here and assumed the famous name Trimbakeshwar. Interestingly, locals refer to the river here as Ganga and not as Godavari. All the heavenly Gods promised to come down to Nasik, once in twelve years, when Jupiter resides in the zodiac sign of Leo. A grand fair is organized at this place. Devotees take a holy bath in the Gautami Ganga and then seek the blessings of Trimbakeshwar.</p>
											</div>
										</div>
											<div class="col-md-6">
											<img src="images/guruji/ser-img/trambak.jpg" class="img-fluid" alt="">
										</div>
									</div>
								</div>
                        </div>
                    </div>
                </div>
                
            </section>

<?php include'footer.php';?>