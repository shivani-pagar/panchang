<?php include'header.php';?>
 <!-- Title Bar -->
         <div class="pbmit-title-bar-wrapper " style="background-image:url(images/guruji/ser-img/bgser.jpg);">
            <div class="auto-container paddcon">
              <div class="row">
                  <div class="col-md-7 col-lg-7">
                       <div class="pbmit-title-bar-content">
                  <div class="pbmit-title-bar-content-inner">
                     <div class="pbmit-tbar">
                        <div class="pbmit-tbar-inner container">
                           <h1 class="pbmit-tbar-title">SAT CHANDI POOJA TRIMBAKESHWAR</h1>
                        </div>
                     </div>
                     <div class="pbmit-breadcrumb">
                        <div class="pbmit-breadcrumb-inner">
                           <span><a title="" href="index.php" class="home"><span>Home</span></a></span>
                           <span class="sep">-</span>
                           <span><span class="post-root post post-post current-item">Sat Chandi Pooja</span></span>
                        </div>
                     </div>
                  </div>
               </div>
                  </div>
                             <div class="col-md-5 col-lg-5">
                   <div class="form-wrp">
                       <form method="post" id="contact-form">
									<div class="row"> 
									<div class="col-md-12">
									   <h2 class="pbmit-titlee">MAKE AN ENQUIRY</h2>
									</div>
										<div class="col-md-12">
											<input type="text" name="name" class="form-control" placeholder="Your Name" required="">
										</div>
										<div class="col-md-12">
											<input type="text" name="transport-type" class="form-control" placeholder="Phone" required="">
										</div>
										<div class="col-md-12">
											<input type="date" name="subject" class="form-control" placeholder="Email" required="">
										</div>
										<div class="col-md-12">
											<button type="submit" class="pbmit-btn w-100">
												<i class="form-btn-loader fa fa-circle-o-notch fa-spin fa-fw margin-bottom d-none"></i>
												Book Your Puja
											</button>
										</div>
										
									</div>
								</form>
                   </div>
               </div>
              </div>
            </div>
         </div>
         <!-- Title Bar End-->
         
         
          <section class="mainsection">
				<div class="container">
					<div class="row align-items-center">
						<!--<div class="col-lg-4 service-left-col order-2 order-lg-1">-->
						<!--	<aside class="service-sidebar">-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="all-post-list">-->
						<!--				<ul>-->
						<!--					<li><a href="services-details.html">  Kalsarp Yog Puja </a></li>-->
						<!--					<li class="post-active"><a href="services-details.html"> Rudrabhisek </a></li>-->
						<!--					<li><a href="services-details.html">  Mahamrityunjay  pooja  </a></li>-->
						<!--					<li><a href="services-details.html"> Pitru dosh  </a></li>-->
						<!--					<li><a href="services-details.html"> Navgrah shaanti  </a></li>-->
						<!--				</ul>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="textwidget">-->
						<!--				<div class="single-service-contact">-->
						<!--					<div class="single-service-contact-inner">-->
						<!--						<span><i class="pbmit-moversco-business-icon-headset"></i></span>-->
						<!--						<h3>For More Details<br> Call Us</h3>-->
						<!--						<ul class="ctc">-->
						<!--							<li>-->
						<!--								<i class="pbmit-base-icon-phone"></i> <a href="tel:+91 9890702222">-->
						<!--								    +91 9890702222-->
						<!--								</a> -->
						<!--							</li>-->
												
						<!--						</ul>-->
						<!--					</div>-->
						<!--				</div>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--	</aside>-->
						<!--</div>-->
						<div class="col-lg-6 col-md-6  order-1">
							<img src="images/guruji/ser-img/Durga.jpg" class="w-100" alt="">
						
						</div>
						<div class="col-md-6 col-lg-6"> 
						    	<div class="service-details">
								<h3 class="pbmit-title">Sat Chandi Pooja</h3>
								<p>Sat chandi pooja is the worship of God as Mother. A yajna is performed to attract the attention of a particular deity, so with Chandi we are calling the Mother and asking for Her help. This depends on our devotion. This is a yajna of bhakti. The yajna area is considered sacred and must be treated with respect and decorum. Mother knows all our needs and wants, yet we still have to ask Her. It is the mother's job to raise the child and provide for its needs, so make a sankalpa asking the Divine Mother to help with your needs." Nine planets form an orbit called Navagraha Mandal.	</p>
								<p>Importance gross inanimate world from the tyranny of the demons was Trahi Trahi Mach, Brahma Vishnu Mahesh then served as the Superpowers Mother Mother Durga manifested universe took place, and Mother Durga pleased with this worship took place and the blessings of the gods demanded. Then the gods fear to free the earth from demons urged Mother Durga. Mother Mahakali be described as killing the demons in mythology Sridurgasptsati Markndey G is described in the book. Sridurgasptsati to 108 times the text is called Stcndeepat Mahayagna, text to 1000 times called Shssrcndi Mahayagna Lcshycndi Mahayagna text is called a million times over. Brahmins with nine in nine days is performed.</p>
								<p>Stcndeepat Mahayagna benefit from this text, under certain conditions, such as human life, conquer enemies, Manipulation job attainment, job promotion, business growth, freedom from oppression and strife in the family, and to get rid of troubles of various kinds made goes.</p>
							
								
							
							</div>
						</div>
					</div>
				</div>
            </section>
            
            
            <section  class="py-5" style="background-image: url(images/guruji/ser-img/ctcbgg.jpg);
                                        height: 300px;
                                        width: 100%;
                                        background-size: cover;
                                        background-position: center;">
                                    <div class="container">
                                        <div class="row justify-content-end">
                                            <div class="col-md-6">
                                                <div>
                                                    <h2>Book Your Puja with Ease</h2>
                                                    <p>Experience divine blessings with a hassle-free booking for your sacred rituals.</p>
                                                    <a href="contact.php" class="pbmit-btnn pbmit-btn-lg">Book Your Puja</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
            
            <section> 
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="service-page-infobox">
									<div class="row align-items-center">
								
                                <div class="con-ser">
                                <h3 class="pbmit-title">Positive Effects Of Sat Chandi Pooja At Trimbakeshwar</h3> 
                               
                                    <p>The Sat Chandi pooja at Trimbakeshwar with samputit path is performed for attainment of soothes of life and lots of glee and affluence. This yagya is strong and adequate to confiscate the state of fear from its devotees. It frees you from the debts and prevents all kinds of misfortune and agony. The yagya grants the disciple with success, authority and power. The yagya kills all the demons and evil forces coming in life. The prayer executed brings in plentiful opulence; melt down the ego and gives strength in life. The yagya makes us spiritually and mentally strong. It enhances the sleep energy and opens the path of salvation. The yagya with samputit invokes the positive energy surrounding us and helps in conquering the enemies of our life.</p>
                                  
                                    

                               
                            </div>
                             <div class="service-page-infobox">
									<div class="row align-items-center">
									
										<div class="col-md-6">
											<div class="service-list-group">
												<h3 class="pbmit-title" >About Trimbakeshwar in Nashik</h3>
												<p class="text-justify">Shri Trimbakeshwar Temple is located at a distance of about 30-km from Nasik in Maharashtra near the mountain named Brahmagiri from which the river Godavari flows. Trimbakeshwar Temple is revered as one of the 12 Jyotirlinga shrines of Shiva and as the source of the river Godavari. Just as Ganga is known as Bhagirathi and is one of the most important rivers in North India, in the same way, Godavari is also known as Gautami Ganga and is the most sacred river in South India. According to Shiv Purana, it is because of the earnest request of Godavari, Gautam Rishi and other gods that Lord Shiva agreed to reside here and assumed the famous name Trimbakeshwar. Interestingly, locals refer to the river here as Ganga and not as Godavari. All the heavenly Gods promised to come down to Nasik, once in twelve years, when Jupiter resides in the zodiac sign of Leo. A grand fair is organized at this place. Devotees take a holy bath in the Gautami Ganga and then seek the blessings of Trimbakeshwar.</p>
											</div>
										</div>
											<div class="col-md-6">
											<img src="images/guruji/ser-img/trambak.jpg" class="img-fluid" alt="">
										</div>
									</div>
								</div>
                        </div>
                    </div>
                </div>
                
            </section>

<?php include'footer.php';?>