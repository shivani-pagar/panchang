
       <?php include'header.php';?>
		<!-- Page Content -->
		<div class="page-content demo-five">
		    
		    
		    <!--<section class="position-relative">-->
		    <!--    <div class="swiper-container demo">-->
		    <!--        <div class="swiper-wrapper">-->
		    <!--            <div class="swiper-slide">-->
		    <!--                      <div class="bg-img" style="background-image:url(images/guruji/arti.jpg); background-size:cover;">-->
      <!--                         <div class="container">-->
      <!--                      <div class="row"> -->
      <!--                          <div class="col-12">-->
      <!--                              <div class="banner-con">-->
      <!--                                  <h1>Book Your Personalized Puja Online...</h1>-->
      <!--                                  <p>Experience Divine Blessings from the Comfort of Your Home</p>-->
      <!--                                  <a href="our-team.html" class="pbmit-btnn pbmit-btn-lg">Book Now</a>-->
      <!--                              </div>-->
      <!--                          </div>   -->
      <!--                      </div>-->
      <!--                  </div>-->
      <!--              </div>-->
		    <!--            </div>-->
		    <!--                 <div class="swiper-slide">-->
		    <!--                      <div class="bg-img" style="background-image:url(images/guruji/arti.jpg); background-size:cover;">-->
      <!--                         <div class="container">-->
      <!--                      <div class="row"> -->
      <!--                          <div class="col-12">-->
      <!--                              <div class="banner-con">-->
      <!--                                  <h1> Your Personalized Puja Online...</h1>-->
      <!--                                  <p>Experience Divine Blessings from the Comfort of Your Home</p>-->
      <!--                                  <a href="our-team.html" class="pbmit-btnn pbmit-btn-lg">Book Now</a>-->
      <!--                              </div>-->
      <!--                          </div>   -->
      <!--                      </div>-->
      <!--                  </div>-->
      <!--              </div>-->
		    <!--            </div>-->
		    <!--        </div>-->
		    <!--         <div class="swiper-pagination text-center"></div>-->
		    <!--    </div>-->
		    <!--</section>-->
		    
		    
		    
		<section class="slider-wrp position-relative">
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <!-- Slide 1 -->
                <div class="swiper-slide">
                    <div class="bg-img" style="background-image:url(images/guruji/bg1.jpg); background-size:cover;">
                               <div class="container">
                            <div class="row align-items-center"> 
                                <div class=" col-12 col-md-6">
                                    <div class="banner-conn">
                                        <h1  style="">Book Your Personalized<span> Puja Online...</span> </h1>
                                        
                                        <p >Experience Divine Blessings from the Comfort of Your Home</p>
                                        <a href="#book" class="pbmit-btnn pbmit-btn-lg">Book Now</a>
                                    </div>
                                </div>  
                                <div class=" col-12 col-md-6">
                                   <div class="">
                                        <img src="images/guruji/mock.png" class="img-fluid">
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                <!-- Slide 2 -->
                <div class="swiper-slide">
                    <div class="bg-img" style="background-image:url(images/guruji/bg2.jpg); background-size:cover;">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class=" col-12 col-md-6">
                                    <div class="banner-conn">
                                        <h1>Special Festival Puja Services</h1>
                                        <p>Celebrate with Traditional Vedic Rituals</p>
                                        <a href="contact.php" class="pbmit-btnn pbmit-btn-lg">Contact Us</a>
                                    </div>
                                </div> 
                                 <div class=" col-12 col-md-6">
                                   <div class="">
                                        <img src="images/guruji/mock2.png" class="img-fluid">
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slide 3 -->
                <div class="swiper-slide"> 
                    <div class="bg-img" style="background-image:url(images/guruji/bg3.jpg); background-size:cover;">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class=" col-12 col-md-6">
                                    <div class="banner-conn">
                                        <h1>Find Experienced Pandits for Every Ritual</h1>
                                        <p>Authentic Vedic Pujas for Every Occasion</p>
                                        <a href="#book" class="pbmit-btnn pbmit-btn-lg">Book Now</a>
                                    </div>
                                </div> 
                                  <div class=" col-12 col-md-6">
                                   <div class="">
                                        <img src="images/guruji/pandit.png" class="img-fluid">
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Navigation & Pagination -->
            <!--<div class="swiper-button-next"></div>-->
            <!--<div class="swiper-button-prev"></div>-->
            <div class="swiper-pagination text-center"></div>
        </div>
    
</section>
 <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
		    <script>
  var swiper = new Swiper(".swiper-container", {
    slidesPerView: 1,  
    spaceBetween: 10,
    loop: false,
    
    // autoplay: {
    //   delay: 10000,
    //   disableOnInteraction: false,
    // },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
  });
</script>
	 
			<!-- Icon Box Start --> 
          <section class="icon-box-six">
				<div class="container-fluid"> 
					<div class="row"> 
					<div class="col-12 text-center mb-3" >
					    <div class="pbmit-heading-subheading-style-1">
									<h4 class="pbmit-subtitle">About Online puja</h4>
									<h2 class="pbmit-title">How does Rakesh Guruji's <strong>Online Puja Service Work?</strong></h2>
								</div>
					</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/agni-pooja.png" class="img-fluid">
											
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">Choose Your Puja</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">Select your Puja from the List</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/id-card.png" class="img-fluid">
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">Your Information</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">The video of your Puja completed with your name and Gotra will be shared on WhatsApp.</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/online-video.png" class="img-fluid">
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">
Puja video</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">Puja Prashad will be sent to your registered address.</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/avatar.png" class="img-fluid">
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">Puja Prashad</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">Puja Prashad will be sent to your registered address.</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section> 
			<!-- Icon Box End -->
		 <?php include'counter.php';?>
			    <!-- About Start --> 
            <section>
               	<div class="container">
					<div class="about-five-box"> 
						<div class="row align-items-center">
							<div class="col-md-12 col-lg-6">
								<div class="pbmit-heading-subheading-style-1">
									<h4 class="pbmit-subtitle">About Rakesh Guruji</h4>
									<h2 class="pbmit-title">Expert Kaalsarp Pooja by <strong>Pandit Rakesh Tripathi in Trimbakeshwar</strong></h2>
								</div>
								<img src="images/guruji/rgab.jpg" class="img-fluid brad" alt="">
							</div>
							<div class="col-md-12 col-lg-6">
								<div class="about-five-content">
									<p class="">Pandit Rakesh Tripathi's Family lives in Trimbakeshwar since 10 years. Being Kaalsarp Pooja experts Guruji have develop expertises in conducting Kaalsarp Pooja as Guruji has perfromed more than 2000+ Kaalsarp Shanti Pooja's till date, and all the Clients(Yajman) get outstanding results immediatly after performing shanti or Pooja Vidhi.</p>
								
									<div class="row g-0">
										<div class="col-md-8">
											<ul class="list-group list-group-borderless">
												<li class="list-group-item">
													<i class="fa fa-check"></i>
													<span>10+ Years of Experience </span>
												</li>
												<li class="list-group-item">
													<i class="fa fa-check"></i>
													<span>2000+ Successful Kaalsarp Shanti Poojas</span>
												</li>
												<li class="list-group-item">
													<i class="fa fa-check"></i>
													<span>Immediate Positive Outcomes</span>
												</li>
												<li class="list-group-item">
													<i class="fa fa-check"></i>
													<span>Authentic & Traditional Pooja Vidhi</span>
												</li>
											</ul>
											
											 <a href="about.php" class="pbmit-btnn pbmit-btn-lg mt-5">Read More</a>
										</div>
										<div class="col-md-4"> 
											<div class="about-five-iconbox">
												<div class="about-five-icon">
													
												</div>
												<div class="about-iconbox-title">
													<h5>WE’RE TRUSTED BY MORE THAN 
														<a href="#" class="text-danger">4500 <span>CLIENTS</span></a>
													</h5>
												</div>	
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
               	</div>
            </section>
            <!-- Service Start -->
          <section class="service-slider-four" id="book">
				<div class="container">
					<div class="service-four-content">
						<div class="row align-items-center">
							<div class="col-md-5">
								<div class="pbmit-heading-subheading-style-1">
									<h4 class="pbmit-subtitle">Authentic Vedic Rituals for a Blessed Life</h4>
									<h2 class="pbmit-title">Expert Kaalsarp Pooja Services by <strong> Pandit Rakesh Tripathi </strong></h2>
								</div>
							</div>
							<div class="col-md-7">
								<p>Kal Sarp Dosh, Pitru Dosh, and planetary imbalances can create obstacles in life. Performing sacred poojas like Mahamrityunjay Jaap, Navgrah Shanti, and Rudrabhishek brings peace, prosperity, and divine blessings.</p>
							</div>
						</div>
					</div>
					<div class="swiper-slider pbmit-element-viewtype-carousel-1 swiper-initialized swiper-horizontal swiper-pointer-events"  data-autoplay="true" data-dots="true" data-arrows="false" data-columns="3" data-margin="30" data-effect="slide">
						<div class="swiper-wrapper" id="swiper-wrapper-8268c983b77ef6cd" aria-live="off" style="transform: translate3d(-3618px, 0px, 0px); transition-duration: 0ms;">
						    <div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 9" style="width: 372px; margin-right: 30px;"> 
								<!-- Slide7 --> 
								<article class="pbminfotech-servicebox-style-3">
									<div class="pbminfotech-post-item">
										<span class="pbminfotech-item-thumbnail">
											<span class="pbminfotech-item-thumbnail-inner">
												<img src="images/guruji/services/3.jpg" class="img-fluid" alt="">
											</span>
										</span>		
										<div class="pbmit-ihbox-icon">
										<img src="images/guruji/om.png" class="img-fluid">		
										</div>
										<div class="pbminfotech-box-content">
											<div class="pbminfotech-box-content-inner">
												<div class="pbminfotech-box-category">
													<a href="#" rel="tag" tabindex="0">Ancestral karma affecting life’s progress.</a>
												</div>
												<div class="pbminfotech-pf-box-title">
													<h3>
										<a href="contact.php" tabindex="0">Pitru dosh 
</a>
													</h3>
												</div>
												<div class="pbminfotech-service-content">
													<p>Pitru Dosh occurs due to unfulfilled ancestral desires, causing struggles in career, health, and family. Performing Pitru Dosh Nivaran Puja brings peace to ancestors, removes negativity, and enhances growth and happiness.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="contact.php" tabindex="0">Book Puja</a>
												</div>
											</div>
										</div>
									</div>
								</article>
							</div>
							<div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 9" style="width: 372px; margin-right: 30px;"> 
								<!-- Slide8 --> 
								<article class="pbminfotech-servicebox-style-3">
									<div class="pbminfotech-post-item">
										<span class="pbminfotech-item-thumbnail">
											<span class="pbminfotech-item-thumbnail-inner">
												<img src="images/guruji/services/4.jpg" class="img-fluid" alt="">
											</span>
										</span>		
										<div class="pbmit-ihbox-icon">
											<img src="images/guruji/om.png" class="img-fluid">		
										</div>
										<div class="pbminfotech-box-content">
											<div class="pbminfotech-box-content-inner">
												<div class="pbminfotech-box-category">
													<a href="#" rel="tag" tabindex="0">Powerful mantra for health and longevity.</a>
												</div>
												<div class="pbminfotech-pf-box-title">
													<h3>
														<a href="contact.php" tabindex="0"> Mahamrityunjay  pooja </a>
													</h3>
												</div>
												<div class="pbminfotech-service-content">
													<p>Mahamrityunjay Jaap is dedicated to Lord Shiva and removes fear of untimely death, diseases, and negative energies. Chanting this mantra provides strength, healing, and spiritual protection. It is especially beneficial for those facing health challenges.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="contact.php" tabindex="0">Book Puja</a>
												</div>
											</div>
										</div>
									</div>
								</article>
							</div>
							<div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="8" role="group" aria-label="9 / 9" style="width: 372px; margin-right: 30px;"> 
								<!-- Slide9 --> 
								<article class="pbminfotech-servicebox-style-3">
									<div class="pbminfotech-post-item">
										<span class="pbminfotech-item-thumbnail">
											<span class="pbminfotech-item-thumbnail-inner">
												<img src="images/guruji/services/5.jpg" class="img-fluid" alt="">
											</span>
										</span>		
										<div class="pbmit-ihbox-icon">
											<img src="images/guruji/om.png" class="img-fluid">		
										</div>
										<div class="pbminfotech-box-content">
											<div class="pbminfotech-box-content-inner">
												<div class="pbminfotech-box-category">
													<a href="#" rel="tag" tabindex="0">Sacred Shiva Abhishek for peace and success.</a>
												</div>
												<div class="pbminfotech-pf-box-title">
													<h3>
														<a href="contact.php" tabindex="0">Rudrabhisek</a>
													</h3>
												</div>
												<div class="pbminfotech-service-content">
													<p>Rudrabhishek Puja is performed by offering sacred items like milk, honey, and ghee to Lord Shiva. It removes negative energies, brings prosperity, and fulfills desires. This powerful ritual ensures spiritual upliftment and overall well-being.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="contact.php" tabindex="0" class="serbtn">Book Puja</a>
												</div>
											</div>
										</div>
									</div>
								</article>
							</div>
							<div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 9" style="width: 372px; margin-right: 30px;"> 
								<!-- Slide1 --> 
								<article class="pbminfotech-servicebox-style-3">
									<div class="pbminfotech-post-item">
										<span class="pbminfotech-item-thumbnail">
											<span class="pbminfotech-item-thumbnail-inner">
												<img src="images/guruji/services/6.jpg" class="img-fluid" alt="">
											</span>
										</span>		
										<div class="pbmit-ihbox-icon">
											<img src="images/guruji/om.png" class="img-fluid">	
										</div>
										<div class="pbminfotech-box-content">
											<div class="pbminfotech-box-content-inner">
												<div class="pbminfotech-box-category">
													<a href="#" rel="tag" tabindex="0"> Astrological imbalance caused by Rahu-Ketu's planetary alignment.</a>
												</div>
												<div class="pbminfotech-pf-box-title">
													<h3>
														<a href="contact.php" tabindex="0"> kalsarp Yog Puja
</a>
													</h3>
												</div>
												<div class="pbminfotech-service-content">
													<p>Kalsarp Dosha can bring struggles and delays in life. Performing Kalsarp Shanti Puja removes obstacles and brings peace, success, and prosperity. It is performed with Vedic rituals to seek divine blessings.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="contact.php" tabindex="0">Book Puja</a>
												</div>
											</div>
										</div>
									</div>
								</article>
							</div>
								<div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 9" style="width: 372px; margin-right: 30px;"> 
								<!-- Slide1 --> 
								<article class="pbminfotech-servicebox-style-3">
									<div class="pbminfotech-post-item">
										<span class="pbminfotech-item-thumbnail">
											<span class="pbminfotech-item-thumbnail-inner">
												<img src="images/guruji/services/7.jpg" class="img-fluid" alt="">
											</span>
										</span>		
										<div class="pbmit-ihbox-icon">
											<img src="images/guruji/om.png" class="img-fluid">	
										</div>
										<div class="pbminfotech-box-content">
											<div class="pbminfotech-box-content-inner">
												<div class="pbminfotech-box-category">
													<a href="#" rel="tag" tabindex="0">Balancing planetary influences.</a>
												</div>
												<div class="pbminfotech-pf-box-title">
													<h3>
														<a href="contact.php" tabindex="0">Navgrah shaanti </a>
													</h3>
												</div>
												<div class="pbminfotech-service-content">
													<p>Navgrah Shanti Puja is performed to pacify malefic planetary effects and bring positive energy. It enhances career growth, relationships, and overall success by reducing negative planetary influences in one’s horoscope.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="contact.php" tabindex="0">Book Puja</a>
												</div>
											</div>
										</div>
									</div>
								</article>
							</div>
							
							</div>
					<div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal"><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 4"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 5"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 6"></span><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 7" aria-current="true"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 8"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 9"></span></div><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
				</div>
            </section>
            <!-- Service End --> 

           

			<!-- Testimonial Start --> 
			

		<section class="testimonial-six">
				<div class="container-fluid">
					<div class="row g-0">
						<div class="col-md-12 col-xl-5">
							<div class="testimonial-six-title">
								<div class="testimonial-arrow swiper-btn-custom d-flex flex-row-reverse">
									<div class="pbmit-heading-subheading-style-1">
										<h4 class="pbmit-subtitle">Testimonial</h4>
										<h2 class="pbmit-title text-dark"><strong>We are trusted 15+ countries worldwide</strong></h2>
									</div>
								<div class="swiper-buttons"></div><div class="swiper-button-next swiper-button-next-2" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-3a7bcacf97c77126"></div><div class="swiper-button-prev swiper-button-prev-2" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-3a7bcacf97c77126"></div></div>
							</div>
						</div>
						<div class="col-md-12 col-xl-7">
							<div class="testimonial-six-slider">
								<div class="swiper-slider pbmit-element-viewtype-carousel-2 swiper-initialized swiper-horizontal swiper-pointer-events" data-arrows-class="testimonial-arrow" data-loop="true" data-autoplay="true" data-dots="false" data-arrows="true" data-columns="3" data-margin="0" data-effect="slide">
									<div class="swiper-wrapper" id="swiper-wrapper-3a7bcacf97c77126" aria-live="off" style="transform: translate3d(-2496px, 0px, 0px); transition-duration: 1500ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 5" style="width: 312px;">
											<!-- Slide3 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-03.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Victoria Porter</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 5" style="width: 312px;">
											<!-- Slide4 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-04.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">John Smith</h3>
																<span class="pbminfotech-box-footer">Building Owner</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="width: 312px;">
											<!-- Slide5 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-05.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Allien John</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
										<div class="swiper-slide swiper-slide-duplicate-active" data-swiper-slide-index="0" role="group" aria-label="1 / 5" style="width: 312px;">
											<!-- Slide1 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-01.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Jack Daniel</h3>
																<span class="pbminfotech-box-footer">Building Owner</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
										<div class="swiper-slide swiper-slide-duplicate-next" data-swiper-slide-index="1" role="group" aria-label="2 / 5" style="width: 312px;">
											<!-- Slide2 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-02.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Elena Smith</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
										<div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 5" style="width: 312px;">
											<!-- Slide3 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-03.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Victoria Porter</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
										<div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 5" style="width: 312px;">
											<!-- Slide4 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-04.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">John Smith</h3>
																<span class="pbminfotech-box-footer">Building Owner</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
										<div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="width: 312px;">
											<!-- Slide5 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-05.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Allien John</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
									<div class="swiper-slide swiper-slide-duplicate swiper-slide-active" data-swiper-slide-index="0" role="group" aria-label="1 / 5" style="width: 312px;">
											<!-- Slide1 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-01.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Jack Daniel</h3>
																<span class="pbminfotech-box-footer">Building Owner</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div><div class="swiper-slide swiper-slide-duplicate swiper-slide-next" data-swiper-slide-index="1" role="group" aria-label="2 / 5" style="width: 312px;">
											<!-- Slide2 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-02.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Elena Smith</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 5" style="width: 312px;">
											<!-- Slide3 -->
											<article class="pbminfotech-testimonialbox-style-6">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-star"> 
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i>  
															<i class="pbmit-base-icon-star pbmit-skincolor pbmit-active"></i> 
														</div>
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-img">
																<span class="pbminfotech-item-thumbnail">
																<span class="pbminfotech-item-thumbnail-inner">
																<img src="images/homepage-6/testimonial/testimonial-03.jpg" class="img-fluid" alt="">
																</span>
																</span>
															</div>
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Victoria Porter</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div></div>
								<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Testimonial End -->
			
			

		
	

          
        </div>
        <!-- Page Content End -->

       <?php include'footer.php';?> 