<?php include'header.php';?>
 <!-- Title Bar -->
         <div class="pbmit-title-bar-wrapper " style="background-image:url(images/guruji/ser-img/bgser.jpg);">
            <div class="container paddcon"> 
              <div class="row align-items-center">
                  <div class="col-md-7 col-lg-7">
                       <div class="pbmit-title-bar-content">
                  <div class="pbmit-title-bar-content-inner">
                     <div class="pbmit-tbar">
                        <div class="pbmit-tbar-inner container">
                           <h1 class="pbmit-tbar-title">KAALSARP DOSH PUJA IN SHIRDI</h1> 
                        </div>
                     </div>
                     <div class="pbmit-breadcrumb">
                        <div class="pbmit-breadcrumb-inner">
                            <span><a title="" href="index.php" class="home"><span>Home</span></a></span>
                           <span class="sep">-</span>
                           <span><span class="post-root post post-post current-item">Kaalsarp Dosh Puja</span></span>
                        </div>
                     </div>
                  </div>
               </div>
               
               <?php include'rakeshguruji.php';?>
               
            
                  </div>
                             <div class="col-md-5 col-lg-5">
                   <div class="form-wrp">
                       <form method="post" id="contact-form">
									<div class="row"> 
									<div class="col-md-12">
									   <h2 class="pbmit-titlee">MAKE AN ENQUIRY</h2>
									</div>
										<div class="col-md-12">
											<input type="text" name="name" class="form-control" placeholder="Your Name" required="">
										</div>
										<div class="col-md-12">
											<input type="text" name="transport-type" class="form-control" placeholder="Phone" required="">
										</div>
										<div class="col-md-12">
											<input type="date" name="subject" class="form-control" placeholder="Email" required="">
										</div>
										<div class="col-md-12">
											<button type="submit" class="pbmit-btn w-100">
												<i class="form-btn-loader fa fa-circle-o-notch fa-spin fa-fw margin-bottom d-none"></i>
												Book Your Puja
											</button>
										</div>
										
									</div>
								</form>
                   </div>
               </div>
              </div>
            </div>
         </div>
         <!-- Title Bar End-->
         
         
          <section class="mainsection"> 
				<div class="container">
					<div class="row align-items-center">
						<!--<div class="col-lg-4 service-left-col order-2 order-lg-1">-->
						<!--	<aside class="service-sidebar">-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="all-post-list">-->
						<!--				<ul>-->
						<!--					<li><a href="services-details.html">  Kalsarp Yog Puja </a></li>-->
						<!--					<li class="post-active"><a href="services-details.html"> Rudrabhisek </a></li>-->
						<!--					<li><a href="services-details.html">  Mahamrityunjay  pooja  </a></li>-->
						<!--					<li><a href="services-details.html"> Pitru dosh  </a></li>-->
						<!--					<li><a href="services-details.html"> Navgrah shaanti  </a></li>-->
						<!--				</ul>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="textwidget">-->
						<!--				<div class="single-service-contact">-->
						<!--					<div class="single-service-contact-inner">-->
						<!--						<span><i class="pbmit-moversco-business-icon-headset"></i></span>-->
						<!--						<h3>For More Details<br> Call Us</h3>-->
						<!--						<ul class="ctc">-->
						<!--							<li>-->
						<!--								<i class="pbmit-base-icon-phone"></i> <a href="tel:+91 9890702222">-->
						<!--								    +91 9890702222-->
						<!--								</a> -->
						<!--							</li>-->
												
						<!--						</ul>-->
						<!--					</div>-->
						<!--				</div>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--	</aside>-->
						<!--</div>-->
						
						
						
							<!--<div class="col-md-12 col-lg-12"> -->
						 <!--   	<div class="service-details">-->
							<!--	<h3 class="pbmit-title">Kaalsarp Dosh Puja In Shirdi</h3>-->
							<!--	<p>The Kaal Sarp Dosh is formed when all planets come between Rahu and Ketu or when all the stars of fortune or planets get trapped in a vicious circle then it’s time for you to understand that you have KaalSarpYog in your life. Rahu means the mouth of the snake. And Ketu implies the rest of the body of the snake. Rahu and Ketu in the form of a snake swallow all other planets in the Kundali and thus make them inactive and keeps a person away from the positive energy.</p>-->
						 <!--       </div>-->
					  <!--   	</div>-->
						
						
						<div class="col-lg-6 col-md-6  order-1">
							<img src="images/guruji/ser-img/kalsarp.jpg" class="w-100" alt="">
						
						</div>
						<div class="col-md-6 col-lg-6"> 
						    	<div class="service-details">
								<h3 class="pbmit-title">Kaal Sarp Dosh Puja Vidhi In Shirdi</h3>
								<p>The Kaal Sarp Dosh is formed when all planets come between Rahu and Ketu or when all the stars of fortune or planets get trapped in a vicious circle then it’s time for you to understand that you have KaalSarpYog in your life. Rahu means the mouth of the snake. And Ketu implies the rest of the body of the snake. Rahu and Ketu in the form of a snake swallow all other planets in the Kundali and thus make them inactive and keeps a person away from the positive energy.</p>
                                <p>Being a KaalSarp puja expert Guruji has to develop expertise in conducting KaalSarp puja as Guruji has performed more than 2000+ Kaalsarp Shanti Pujas to date, and all the Clients (Yajman) get outstanding results immediately after completing Shanti or Puja Vidhi.</p>
                                <p>People from across the globe have been coming to Shirdi to perform all sorts of vidhis. This is the result of their devoted service in practicing the Hindu rites in Shirdi.</p>
                                <p>We Provide <b><a href="kaalsarp-puja-shirdi.php">kaal sarp dosh pooja Shirdi</a></b>, Tripindi Shraddha, Narayan Nagbali, Nakshatra Shanti, Rudrabhishek, and other vidhis.</p>
                                                                        								
							
							</div>
						</div>
					</div>
				</div>
            </section>
            
            
            <section  class="py-5" style="background-image: url(images/guruji/ser-img/ctcbgg.jpg);
                                        height: 300px;
                                        width: 100%;
                                        background-size: cover;
                                        background-position: center;">
                                    <div class="container">
                                        <div class="row justify-content-end">
                                            <div class="col-md-6">
                                                <div>
                                                    <h2>Book Your Puja with Ease</h2>
                                                    <p>Experience divine blessings with a hassle-free booking for your sacred rituals.</p>
                                                    <a href="contact.php" class="pbmit-btnn pbmit-btn-lg">Book Your Puja</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
            
            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="service-page-infobox">
									<div class="row align-items-center">
										<div class="col-md-6">
											<img src="images/guruji/ser-img/effect.jpg" class="img-fluid" alt="">
										</div>
										<div class="col-md-6">
											<div class="service-list-group">
												<h3 class="pbmit-title" >Why Perform Kaal Sarp Yog Puja At Shirdi?</h3>
												<p>Many know about the KaalSarpDosh in their Kundali but neglect it. That’s when problems in life begin. To succeed in professional life, to create your name and identity in society, and to accomplish all that we desire and wish in life one has to perform <b><a href="kaalsarp-puja-shirdi.php">kaalsarp puja at Shirdi.</a></b></p>
                                                <p><b><a href="kaalsarp-puja-shirdi.php">Kaal Sarp dosh puja vidhi</a></b> is associated with negative energies that can have an effect on the physical, mental, and subconscious state of human beings. It has been said that if the snake has been killed by any person, then Kaal Sarp Dosh can appear in anyone’s kundalini as a family member.</p>
                                                <p> This <b><a href="kaalsarp-puja-shirdi.php">kaalsarp dosh nivaran</a></b> is considered to be more intensive. It’s good to perform this puja as soon as one knows about KaalSarpYog in Kundali.</p>
											</div>
										</div>
									</div>
								</div>
								
								 
								
								
                            <div class="con-ser">
                                <h3 class="pbmit-title">Benefits Of Performing KaalSarp Dosh Nivaran Puja At Shirdi:</h3>
                                <p>Along with KaalSarp Puja, Rahu Ketu puja opens up the doors of success. Get the <b><a href="kaalsarp-puja-shirdi.php">KaalSarp Puja in Shirdi</a></b> and be free from all the ill effects of this dosh. The mind is at peace and one starts thinking in a positive way.</p>
                                <p>Kaal Sarp Dosh Nivaran Puja can be performed at the holy place of Shirdi in India. One gets respect in society and also brings success in professional life. Family relations grow excellent and strong. Kaal Sarp puja protects a person from evil powers and energies.</p>
                                <p>One gets an opportunity to serve his parents and elderly people in the family. To get the best out of your efforts it is essential to revive the power and negativity of the <b><a href="kaalsarp-puja-shirdi.php">Kaal Sarp dosh puja in Shirdi</a></b> and hence improve and enjoy the surplus of your luck and efforts and lead a beautiful and happy life.</p>    
                                    
                                    
                                    
                                    
                            </div>
                             <div class="con-ser">
                                <h3 class="pbmit-title">Who Can Perform KaalSarp Puja?</h3>
                               <p>Only a pandit (brahman) with the knowledge and expertise in performing the KaalSarpDosh puja should perform the puja.</P>
                               <p>The puja can be performed for an individual or even a group of people with the KaalSarpYog in their Kundli.</p>
                               <p>For the best prices of<b><a href="kaalsarp-puja-shirdi.php"> Kaal Sarp puja at Shirdi</a></b> guaranteed we highly recommend contacting Pandit Sagar Guruji. With years of knowledge and experience in helping people get rid of this dreadful dosh in their horoscope, Pandit Sagar Guruji has made a name for himself and has brought back peace and happiness to many former victims of the Kaal Sarp Dosh.</p>
                                                               
                                
                            </div>
                              <div class="con-ser">
                                <h3 class="pbmit-title">Kaalsarp Puja In Shirdi</h3>
                                        <p>Our pandit for <b><a href="kaalsarp-puja-shirdi.php">Kaal Sarp puja in Shirdi</a></b> is an expert in all Hindu religious Puja, Vidhi's, KaalSarp puja, Trapidi Shradha, etc. He oversees all problems and works closely with people to ensure that all expectations are met. He had performed more than 2000 + Kaal Sarp Dosh Nivaran Puja in Shirdi. He is KaalSarp Puja Expert, a Specialist in Shirdi.</p>
                                        <p>Being a KaalSarp puja expert Guruji has to develop expertise in conducting KaalSarp puja as Guruji has performed more than 2000+ Kaalsarp Shanti Pujas to date, and all the Clients (Yajman) get outstanding results immediately after completing Shanti or Puja Vidhi.</p>
                                        <p>People from across the globe have been coming to Shirdi to perform all sorts of vidhis. This is the result of their devoted service in practicing the Hindu rites in Shirdi.</p>
                                        <p>We Provide Tripindi Shraddha, Narayan Nagbali, Nakshatra Shanti, Rudrabhishek, and <b><a href="kaalsarp-puja-shirdi.php">kaal sarp yog puja at Shirdi.</a></b></p>
                                </ul>
                            </div>
                                
                            
                        </div>
                    </div>
                </div>
                
            </section>

<?php include'footer.php';?>