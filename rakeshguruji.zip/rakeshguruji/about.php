<?php include 'header.php';?>


       <div class="pbmit-title-bar-wrapper " style="background-image:url(images/guruji/ser-img/aboubg.jpg);">
            <div class="container paddcon"> 
              <div class="row align-items-center">
                  <div class="col-md-7 col-lg-7 order-md-2">
                       <div class="pbmit-title-bar-content">
                  <div class="pbmit-title-bar-content-inner">
                     <div class="pbmit-tbar">
                        <div class="pbmit-tbar-inner container">
                           <h1 class="pbmit-tbar-title">About Us</h1> 
                        </div>
                     </div>
                     <div class="pbmit-breadcrumb">
                        <div class="pbmit-breadcrumb-inner">
                           <span><a title="" href="index.php" class="home"><span>Home</span></a></span>
                           <span class="sep">-</span>
                           <span><span class="post-root post post-post current-item">About Us</span></span>
                        </div>
                     </div>
                  </div>
               </div>
               
               <?php include'rakeshguruji.php';?>
               
            
                  </div>
                             <div class="col-md-5 col-lg-5">
                   <div class="form-wrp">
                       <form method="post" id="contact-form">
									<div class="row"> 
									<div class="col-md-12">
									   <h2 class="pbmit-titlee">MAKE AN ENQUIRY</h2>
									</div>
										<div class="col-md-12">
											<input type="text" name="name" class="form-control" placeholder="Your Name" required="">
										</div>
										<div class="col-md-12">
											<input type="text" name="transport-type" class="form-control" placeholder="Phone" required="">
										</div>
										<div class="col-md-12">
											<input type="date" name="subject" class="form-control" placeholder="Email" required="">
										</div>
										<div class="col-md-12">
											<button type="submit" class="pbmit-btn w-100">
												<i class="form-btn-loader fa fa-circle-o-notch fa-spin fa-fw margin-bottom d-none"></i>
												Book Your Puja
											</button>
										</div>
										
									</div>
								</form>
                   </div>
               </div>
              </div>
            </div>
         </div>


         
         <section class="section-md">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="pbmit-heading-subheading-style-1">
								<h4 class="pbmit-subtitle">About Us</h4>
								<h2 class="pbmit-title">About <strong> PANDIT RAKESH TRIPATHI</strong></h2>
							</div>
							<p>Pandit Rakesh Tripathi's Family lives in Trimbakeshwar since 10 years. Being Kaalsarp Pooja experts Guruji have develop expertises in conducting Kaalsarp Pooja as Guruji has perfromed more than 2000+ Kaalsarp Shanti Pooja's till date, and all the Clients(Yajman) get outstanding results immediatly after performing shanti or Pooja Vidhi.</p>
						 	<div class="about-us-left-img">
								<img src="images/guruji/ser-img/aboutpooja.jpg" class="img-fluid w-100" alt="">
							</div> 
						</div> 
						<div class="col-md-6">
							<div class="about-us-right-box">
								<img src="images/guruji/ser-img/about2.jpg" class="img-fluid w-100" alt="">
								<h5 class="pbmit-title">We Provide Best Services</h5>
								<div class="row">
									<div class="col-md-6">
										<ul class="list-group list-group-one list-group-borderless">
											<li class="list-group-item">
												<i class="fa fa-check"></i>Family Problem Solution
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>Business Problem Solution
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>Divorce Problem Solution
											</li>
										</ul>
									</div>	
									<div class="col-md-6">
										<ul class="list-group list-group-one list-group-borderless">
											<li class="list-group-item">
												<i class="fa fa-check"></i>Financial Problem Solution
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>Job Problem Solution
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>Love Marriage Solution
											</li>
										</ul>
									</div>
									<div class="col-md-12">
									    <div class="mt-3">
									        <h3>
									            For more details call us: +91 <a href="tel:9890702222">9890702222</a>
									        </h3>
									    </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			
			<section class="icon-box-six">
				<div class="container-fluid"> 
					<div class="row"> 
					<div class="col-12 text-center mb-3">
					    <div class="pbmit-heading-subheading-style-1">
									<h4 class="pbmit-subtitle">About Online puja</h4>
									<h2 class="pbmit-title">How does Rakesh Guruji's <strong>Online Puja Service Work?</strong></h2>
								</div>
					</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/agni-pooja.png" class="img-fluid">
											
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">Choose Your Puja</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">Select your Puja from the List</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/id-card.png" class="img-fluid">
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">Your Information</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">The video of your Puja completed with your name and Gotra will be shared on WhatsApp.</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/online-video.png" class="img-fluid">
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">
Puja video</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">Puja Prashad will be sent to your registered address.</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xl-3">
							<div class="pbminfotech-ihbox-style-11">
								<div class="pbminfotech-ihbox-inner">
									<div class="pbminfotech-ihbox-icon pbminfotech-large-icon">
										<div class="pbminfotech-ihbox-icon-wrapper">
											<img src="images/guruji/avatar.png" class="img-fluid">
										</div>
									</div>
									<div class="pbminfotech-ihbox-contents">
										<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
											<div class="pbminfotech-vc_cta3_content-container">
												<div class="pbminfotech-vc_cta3-content">
													<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
														<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
															<h2 class="pbminfotech-custom-heading">Puja Prashad</h2>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="pbminfotech-cta3-content-wrapper">Puja Prashad will be sent to your registered address.</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			
			<?php include'counter.php';?>


<?php include 'footer.php';?>