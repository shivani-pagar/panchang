<?php include'header.php';?>
 <!-- Title Bar -->
         <div class="pbmit-title-bar-wrapper " style="background-image:url(images/guruji/ser-img/bgser.jpg);">
            <div class="container paddcon">
              <div class="row align-items-center">
                  <div class="col-md-7 col-lg-7">
                       <div class="pbmit-title-bar-content">
                  <div class="pbmit-title-bar-content-inner">
                     <div class="pbmit-tbar">
                        <div class="pbmit-tbar-inner container">
                           <h1 class="pbmit-tbar-title">Rudra Abhishek Pooja Trimbakeshwar</h1>
                        </div>
                     </div>
                     <div class="pbmit-breadcrumb">
                        <div class="pbmit-breadcrumb-inner">
                           <span><a title="" href="index.php" class="home"><span>Home</span></a></span>
                           <span class="sep">-</span>
                           <span><span class="post-root post post-post current-item">Rudra Abhishek Pooja</span></span>
                        </div>
                     </div>
                  </div>
               </div>
                <?php include'rakeshguruji.php';?>
                  </div>
                             <div class="col-md-5 col-lg-5">
                   <div class="form-wrp">
                       <form method="post" id="contact-form">
									<div class="row"> 
									<div class="col-md-12">
									   <h2 class="pbmit-titlee">MAKE AN ENQUIRY</h2>
									</div>
										<div class="col-md-12">
											<input type="text" name="name" class="form-control" placeholder="Your Name" required="">
										</div>
										<div class="col-md-12">
											<input type="text" name="transport-type" class="form-control" placeholder="Phone" required="">
										</div>
										<div class="col-md-12">
											<input type="date" name="subject" class="form-control" placeholder="Email" required="">
										</div>
										<div class="col-md-12">
											<button type="submit" class="pbmit-btn w-100">
												<i class="form-btn-loader fa fa-circle-o-notch fa-spin fa-fw margin-bottom d-none"></i>
												Book Your Puja
											</button>
										</div>
										
									</div>
								</form>
                   </div>
               </div>
              </div>
            </div>
         </div>
         <!-- Title Bar End-->
         
         
          <section class="mainsection">
				<div class="container">
					<div class="row align-items-center">
						<!--<div class="col-lg-4 service-left-col order-2 order-lg-1">-->
						<!--	<aside class="service-sidebar">-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="all-post-list">-->
						<!--				<ul>-->
						<!--					<li><a href="services-details.html">  Kalsarp Yog Puja </a></li>-->
						<!--					<li class="post-active"><a href="services-details.html"> Rudrabhisek </a></li>-->
						<!--					<li><a href="services-details.html">  Mahamrityunjay  pooja  </a></li>-->
						<!--					<li><a href="services-details.html"> Pitru dosh  </a></li>-->
						<!--					<li><a href="services-details.html"> Navgrah shaanti  </a></li>-->
						<!--				</ul>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--		<aside class="widget post-list">-->
						<!--			<div class="textwidget">-->
						<!--				<div class="single-service-contact">-->
						<!--					<div class="single-service-contact-inner">-->
						<!--						<span><i class="pbmit-moversco-business-icon-headset"></i></span>-->
						<!--						<h3>For More Details<br> Call Us</h3>-->
						<!--						<ul class="ctc">-->
						<!--							<li>-->
						<!--								<i class="pbmit-base-icon-phone"></i> <a href="tel:+91 9890702222">-->
						<!--								    +91 9890702222-->
						<!--								</a> -->
						<!--							</li>-->
												
						<!--						</ul>-->
						<!--					</div>-->
						<!--				</div>-->
						<!--			</div>-->
						<!--		</aside>-->
						<!--	</aside>-->
						<!--</div>-->
						<div class="col-lg-6 col-md-6  ">
							<img src="images/guruji/ser-img/Rudra-Abhishak.jpg" class="w-100" alt="">
						</div>
						<div class="col-md-6 col-lg-6"> 
						    	<div class="service-details">
								<h3 class="pbmit-title">Rudra Abhishek Pooja</h3>
								<p>Rudra Abhishek pooja at trimbakeshwar is a ritual where Panchamrut Pooja is offered to lord Trimbakeshwara with powerful hymns/mantras to fulfill all the wishes of the person who gets it performed.</p>
								<p>This abhisheka bestows prosperity, fulfillment of all desires, it removes negativity, cuts off the negative karma and gives all round happiness in life.</p>
								<p>The Panchamrut pooja contains Milk,Curd,Ghee,Honey and Sugar.</p>
								<p>It is done for fulfilling our desires, and for prosperity. It is a very special type of pooja which is done by only Local Brahmins of the Trimbakeshwar at the temple .This bestows prosperity, fulfillment and give all aground happiness in life Abhisheka is performed by Chanting the verses of Sanskrit shlokas ('Suktas') (Rudra )and simultaneously offering either holy leaves, holy water, honey, Milk, curd (yogurt), sugar, cane juice to Lord Trimbakeshwar.</p>
								<p>Verses are Pronounced loudly by priests. They are written in ('San-Skrit' language pronounced as sun-s-krita ) ancient Indian language. There is a belief that this language is used for communication by God.Priest's usually can chant in this language. The vibrations generated from this chanting heals the mind of listeners and will give him/her peace of mind.</p>
							
							</div>
						</div>
							<div class="col-md-12">
						    <p>Rudra Abhishek Pooja is an ancient practice followed in India since time immemorial. ‘Rudra’ means ‘Shiva - the Benevolent', ' the Destroyer of Evil'. 'Pooja' means that which is born out of fullness. Through this Pooja one can aim for inner peace and fulfillment. In this Pooja, Lord Shiva is worshiped in his Rudra form.</p>
								
								<p>It is hailed by all Vedic scriptures as one of the greatest Poojas to remove all evils, to attain all desires and for all-round prosperity. Scriptures on Astrology prescribe this emphatically as a remedy for several planetary doshas.</p>
						</div>
					
					</div>
				</div>
            </section>
            
            
            <section  class="py-5" style="background-image: url(images/guruji/ser-img/ctcbgg.jpg);
                                        height: 300px;
                                        width: 100%;
                                        background-size: cover;
                                        background-position: center;">
                                    <div class="container">
                                        <div class="row justify-content-end">
                                            <div class="col-md-6">
                                                <div>
                                                    <h2>Book Your Puja with Ease</h2>
                                                    <p>Experience divine blessings with a hassle-free booking for your sacred rituals.</p>
                                                    <a href="contact.php" class="pbmit-btnn pbmit-btn-lg">Book Your Puja</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
            
            <section> 
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="service-page-infobox">
									<div class="row align-items-center">
										<div class="col-md-6">
											<img src="images/guruji/ser-img/Rudra.jpg" class="img-fluid" alt="">
										</div>
										<div class="col-md-6">
											<div class="service-list-group">
												<h3 class="pbmit-title" >Why Rudra Abhishek ?</h3>
										
												<p>The world is a play of energy: negative and positive. When we pray to Shiva – the Lord of transformation - the entire negative energy around us in the form of disease, depression, and unhappiness gets transformed into peace, prosperity and joy. Then peace surrounds us in body, mind and soul.</p>
											
											</div>
										</div>
									</div>
								</div>
								
								 
								
								
                            
                                <div class="con-ser">
                                <h3 class="pbmit-title">How To Perform Rudra Abhishek Pooja At Trimbakeshwar  ?</h3> 
                               
                                    <p>This Pooja is performed with a crystal 'linga'. Each ancient mantra that is chanted gets absorbed in materials like curd, milk, ghee, honey etc. which are used as offerings in the Pooja. It is then offered to Lord Shiva with reverence, love and gratitude. Specially trained Pandits and Veda students from the Veda Agama (Vedic school) perform this special Pooja. The chanting of the mantras is so pure and meditative that it takes one to a different plane.</p>
                                    
                            </div>
                             <div class="service-page-infobox">
									<div class="row align-items-center">
									
										<div class="col-md-6">
											<div class="service-list-group">
												<h3 class="pbmit-title" >About Trimbakeshwar in Nashik</h3>
												<p class="text-justify">Shri Trimbakeshwar Temple is located at a distance of about 30-km from Nasik in Maharashtra near the mountain named Brahmagiri from which the river Godavari flows. Trimbakeshwar Temple is revered as one of the 12 Jyotirlinga shrines of Shiva and as the source of the river Godavari. Just as Ganga is known as Bhagirathi and is one of the most important rivers in North India, in the same way, Godavari is also known as Gautami Ganga and is the most sacred river in South India. According to Shiv Purana, it is because of the earnest request of Godavari, Gautam Rishi and other gods that Lord Shiva agreed to reside here and assumed the famous name Trimbakeshwar. Interestingly, locals refer to the river here as Ganga and not as Godavari. All the heavenly Gods promised to come down to Nasik, once in twelve years, when Jupiter resides in the zodiac sign of Leo. A grand fair is organized at this place. Devotees take a holy bath in the Gautami Ganga and then seek the blessings of Trimbakeshwar.</p>
											</div>
										</div>
											<div class="col-md-6">
											<img src="images/guruji/ser-img/trambak.jpg" class="img-fluid" alt="">
										</div>
									</div>
								</div>
                        </div>
                    </div>
                </div>
                
            </section>

<?php include'footer.php';?>