 <!-- footer -->
		<footer class="footer site-footer pbmit-bg-color-secondary" style="background-image:url(images/guruji/trbg.jpeg); background-image: url(images/guruji/trbg.jpeg);
    background-size: cover;
    background-position: top center;
    background-attachment: fixed;">
			<div class="pbmit-footer-widget-area-top">
				<div class="container">
					<div class="row">
						<div class="col-md-3">
							<div class="pbmit-footer-boxes">
								<div class="pbmit-footer-contact-info">
                                    <div class="pbmit-footer-contact-info-inner">
                                       <i class="themifyicon ti-headphone"></i>
                                    </div>
									<div class="pbmit-footer-contact-info-wrap">
										<strong>Phone:</strong> <br><a href="tel:+91 9890702222">+91 9890702222</a>
									</div>
                                </div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="pbmit-footer-boxes">
								<div class="pbmit-footer-contact-info">
                                    <div class="pbmit-footer-contact-info-inner">
                                       	<i class="themifyicon ti-location-pin"></i>
                                    </div>
									<div class="pbmit-footer-contact-info-wrap">
										<strong>Address:</strong> <br>Kameshawaranand(Giri) Aashram, Shiv temple, Opp. Bharat Petrol Pump, Near Govt. Rest House, Trimbakeshwar, Nashik 422212.
									</div>
                                </div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="pbmit-footer-boxes">
								<div class="pbmit-footer-contact-info">
                                    <div class="pbmit-footer-contact-info-inner">
                                      	 <i class="themifyicon ti-email"></i>
                                    </div>
									<div class="pbmit-footer-contact-info-wrap">
										<strong>E-mail: </strong> <br><a href="mailto:panditrakeshtripathi@gmail.com;">panditrakeshtripathi@gmail.com</a>
									</div>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pbmit-footer-widget-area">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-lg-3">
							<div class="widget">
								<div class="textwidget">
									<p>
									<a href="index.php">
									    	<img class="pbmit-footerlogo" src="images/guruji/newlogo.png" alt="">
									</a>
									</p>
									<p class="text-white">Pandit Rakesh Tripathi's Family lives in Trimbakeshwar since 10 years.</p>
								</div>
								<div class="pbmit-social-links-wrapper">
									<ul class="social-icons">
										<li class="pbmit-social-facebook">
											<a class=" tooltip-top" target="_blank" href="https://www.facebook.com/people/Kalsarp-Puja-Pandit/100066845362714/">
												<i class="pbmit-base-icon-facebook"></i>
											</a>
										</li>
										<li class="pbmit-social-twitter">
											<a class=" tooltip-top" target="_blank" href="https://in.pinterest.com/KalsarpaPuja/">
												<i class="pbmit-base-icon-pinterest"></i>
											</a>
										</li>
										<li class="pbmit-social-instagram">
											<a class=" tooltip-top" target="_blank" href="#">
												<i class="pbmit-base-icon-instagram"></i>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="widget">
							<h2 class="widget-title">QUICK LINKS</h2>
							<div class="textwidget">
								<ul>
									<li><a href="index.php">Home</a></li>
									<li><a href="about.php">About</a></li>
									<li><a href="kalsarp-yog-puja.php"> kalsarp Yog Puja</a></li>
									<li><a href="#">Our Puja's</a></li>
									<li><a href="gallery.php">Gallery</a></li>
										<li><a href="contact.php">Contacts</a></li>
								</ul>
							</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="widget">
								<h2 class="widget-title">Our Puja's</h2>
								<div class="textwidget">
									<ul>
									    	<li><a href="kalsarp-yog-puja.php">kalsarp Yog Puja</a></li>
									    		<li><a href="mahamrityunjay.php">Mahamrityunjay pooja</a></li>
										<li><a href="pitru-dosh.php">Pitru dosh</a></li>
										<li><a href="rudra-abhishek.php">Rudrabhisek</a></li>
										<li><a href="navgrah-shanti.php">Navgrah shaanti</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="widget">
								<h2 class="widget-title">NEWSLETTER</h2>
								<div class="textwidget">
									<form>
										<input type="email" name="email" placeholder="Your email address" required="">
										<button class="pbmit-btn text-dark" type="submit">Subscribe</button>
									</form>					
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pbmit-footer-bottom"> 
				<div class="container">
					<div class="pbmit-footer-text-inner text-center">
						<div class="row">
							<div class="col-md-12">
								<div class="pbmit-footer-copyright-text-area"> Copyright © 2025 
									<a href="#"></a>. All rights reserved.				
								</div>
							</div>			
						</div>
					</div>	
				</div>
			</div>	
		</footer>
		<!-- footer End -->

	</div>
	<!-- page wrapper End -->

	<!-- Search Box Start Here -->
	<div class="pbmit-search-overlay">
		<div class="pbmit-icon-close"></div>
		<div class="pbmit-search-outer"> 
			<div class="pbmit-search-logo">
				<img src="images/homepage-4/logo-white.png" alt="">
			</div>	
			<form class="pbmit-site-searchform">
				<input type="search" class="form-control field searchform-s" name="s" placeholder="Type Word Then Press Enter">
				<button type="submit">
					<i class="pbmit-base-icon-search"></i>
				</button>
			</form>
		</div>
	</div>
   	<!-- Search Box End Here -->

     <!-- JS
         ============================================ -->
      <!-- jQuery JS -->
      <script src="js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="js/popper.min.js"></script>
      <!-- Bootstrap JS -->
      <script src="js/bootstrap.min.js"></script> 
      <!-- jquery Waypoints JS -->
      <script src="js/jquery.waypoints.min.js"></script>
      <!-- jquery Appear JS -->
      <script src="js/jquery.appear.js"></script>
      <!-- Numinate JS -->
      <script src="js/numinate.min.js"></script>
      <!-- Swiper JS -->
      <script src="js/swiper.min.js"></script>
      <!-- Magnific JS -->
      <script src="js/jquery.magnific-popup.min.js"></script>
      <!-- Circle Progress JS -->
      <script src="js/circle-progress.js"></script>  
	  <!-- AOS -->
      <script src="js/aos.js"></script>
      <!-- Scripts JS -->
      <script src="js/scripts.js"></script>    
      <!-- Revolution JS -->
      <script src="revolution/rslider.js"></script>
      <script src="revolution/rbtools.min.js"></script>
      <script src="revolution/rs6.min.js"></script> 
      
      
   <script>(function(){var js = "window['__CF$cv$params']={r:'81f194b18f5f46a4',t:'MTY5ODgxNDg5Ny4xMzEwMDA='};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../cdn-cgi/challenge-platform/h/b/scripts/jsd/61b90d1d/main.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon='{"rayId":"81f194b18f5f46a4","version":"2023.10.0","r":1,"token":"125856bf84ab44059737e93b01aa0fef","b":1}' crossorigin="anonymous"></script>

<script>
    $(document).ready(function () {
        // Ensure counter works when scrolling into view
        $('.numinate').counterUp({
            delay: 5,  // Speed of counting
            time: 2000 // Duration of animation
        });
    });
</script>


</body>


</html>